document.addEventListener('DOMContentLoaded', () => {
   
    let tasks = [
        { id: 1, text: 'study courses', completed: true },
        { id: 2, text: 'Learn new skill', completed: false },
        { id: 3, text: 'daily DSA practice', completed: false }
    ];

    const taskList = document.getElementById('taskList');
    const newTaskInput = document.getElementById('newTaskInput');
    const addTaskButton = document.getElementById('addTaskButton');

   
    function renderTasks() {
        taskList.innerHTML = ''; 
        tasks.forEach(task => {
            const listItem = document.createElement('li');
            listItem.setAttribute('data-id', task.id);
            if (task.completed) {
                listItem.classList.add('completed');
            }

            const taskTextSpan = document.createElement('span');
            taskTextSpan.textContent = task.text;
            taskTextSpan.addEventListener('click', () => toggleComplete(task.id)); // Click task text to toggle complete

            const actionsDiv = document.createElement('div');
            actionsDiv.classList.add('task-actions');

            const completeButton = document.createElement('button');
            completeButton.classList.add('complete-btn');
            completeButton.textContent = task.completed ? 'Unmark' : 'Complete';
            completeButton.addEventListener('click', () => toggleComplete(task.id));

            const deleteButton = document.createElement('button');
            deleteButton.classList.add('delete-btn');
            deleteButton.textContent = 'Delete';
            deleteButton.addEventListener('click', () => deleteTask(task.id));

            listItem.appendChild(taskTextSpan);
            actionsDiv.appendChild(completeButton);
            actionsDiv.appendChild(deleteButton);
            listItem.appendChild(actionsDiv);

            taskList.appendChild(listItem);
        });
    }

   
    addTaskButton.addEventListener('click', () => {
        const newTaskText = newTaskInput.value.trim();
        if (newTaskText !== '') {
            const newId = tasks.length > 0 ? Math.max(...tasks.map(t => t.id)) + 1 : 1;
            tasks.push({ id: newId, text: newTaskText, completed: false });
            newTaskInput.value = ''; 
            renderTasks();
        } else {
            alert('Task cannot be empty!');
        }
    });

   
    newTaskInput.addEventListener('keypress', (event) => {
        if (event.key === 'Enter') {
            addTaskButton.click();
        }
    });

    
    function toggleComplete(id) {
        tasks = tasks.map(task =>
            task.id === id ? { ...task, completed: !task.completed } : task
        );
        renderTasks();
    }

   
    function deleteTask(id) {
        tasks = tasks.filter(task => task.id !== id);
        renderTasks();
    }

    
    renderTasks();
});